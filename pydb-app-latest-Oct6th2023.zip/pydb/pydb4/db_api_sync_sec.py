import os
import csv
import pandas as pd
from apiclient import discovery
from google.oauth2 import service_account
from datetime import datetime, date, timedelta #, time
from .models import Vendor, Product
from django.db.models import Q
from django.contrib.auth.models import User
# import json
# import time
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import traceback
import threading
from django.db import transaction
from googleapiclient.errors import HttpError

thread_lock = threading.Lock()

# from .pydb import settings
# settings.configure()

"""
10/04/2023:
while changing sheets in API, these things will be different:

old secret_file = client_secret.json
new secret_file = client_secret_omni_z.json

old spreadsheet_ID of copy of items_added =
1Z5khxBtj8BcmWS2AXlZrIXtJVXMG5fJ8OUs8qQFPXP8
old sheet name = "Sheet1"

new spreadsheet_ID of main items new (items added) =
1HwJeDoho1MHS3NJxLdJZgse7YP3A-6C1KIw8YzSX9Eo
new sheet name = "New Items for Inventory FORM"

new spreadsheet_ID of main items used =
1HwJeDoho1MHS3NJxLdJZgse7YP3A-6C1KIw8YzSX9Eo
new sheet name = "Items Used in Procedure FORM"

new spreadsheet_ID of main current inventory (OmniZ) =
1HwJeDoho1MHS3NJxLdJZgse7YP3A-6C1KIw8YzSX9Eo
new sheet name = "Current Inventory"

"""


# composing Q statement for normal search queries
def construct_search_query(queries):
    if len(queries) == 1:
        return queries[0]  # Base case: return the single query
    # Recursive case: combine the first query with the result of the recursive call
    return Q(queries[0]) | construct_search_query(queries[1:])


# alternate search final Q statement will use &'s as operator, so AND operator
def construct_search_query_alternate(queries):
    if len(queries) == 1:
        return queries[0]
    return Q(queries[0]) & construct_search_query(queries[1:])


def convert_date_to_db_format(date_str: str) -> str:
    date = datetime.strptime(date_str, "%m-%d-%Y")
    return date.strftime("%Y-%m-%d")


def convert_date_to_display_format(date_str: str) -> str:
    date = datetime.strptime(date_str, "%Y-%m-%d")
    return date.strftime("%m-%d-%Y")


def convert_date_to_search_format(date_str: str):
    date = datetime.strptime(date_str, "%Y-%m-%d")
    return date

# already imported datetime from datetime, so no need to call it as datetime.datetime.strptime() below
def db_date_format(date_str: str):
    try:
        date_object = datetime.strptime(date_str, "%m-%d-%Y")
        formatted_date = date_object.strftime("%Y-%m-%d")
        date = datetime.strptime(formatted_date, "%Y-%m-%d")
        return date
    except ValueError:
        print("This is not a date, incorrect value.")
        return ''

# same as db_date_format, except input str has / in date instead of -
def db_date_format_alt(date_str):
    try:
        date_object = datetime.strptime(date_str, "%m/%d/%Y")
        formatted_date = date_object.strftime("%Y-%m-%d")
        date = datetime.datetime.strptime(formatted_date, "%Y-%m-%d")
        return date
    except ValueError:
        print("this is not a date, skipping")
        return None

def vendor_list_current() -> list[dict]:
    file = r"/home/omnivascular/pydb4/pydb/vendors.csv"
    data = pd.read_csv(file)
    vendor_dict = data.to_dict(orient="records")
    print("Vendor ID  -  Vendor Name  -  Vendor Abbreviation")
    for v in vendor_dict:
        print(f"{v['id']}  -  {v['name']}  -  {v['abbrev']}")
    return vendor_dict

def sync_vendors_with_csv(csv_file_path=r"/home/omnivascular/pydb4/pydb/vendors.csv") -> None:
    from collections import defaultdict
    # Step 1: Gather all current vendor objects
    vendors_db = Vendor.objects.all()
    # Step 2: Check each vendor object against the CSV
    csv_data = defaultdict(int)  # Create a dictionary to store CSV data counts
    for vendor in vendors_db:
        csv_data[(vendor.id, vendor.name, vendor.abbrev)] += 1
    # Step 3 and 4: Check and write vendors not in CSV
    with open(csv_file_path, 'r', newline='', encoding='utf-8') as csv_file:
        csv_reader = csv.reader(csv_file)
        next(csv_reader)  # Skip the header row
        for row in csv_reader:
            vendor_id, vendor_name, vendor_abbrev = row[0], row[1], row[2]
            vendor_tuple = (vendor_id, vendor_name, vendor_abbrev)
            if csv_data[vendor_tuple] == 0:
                # Vendor is not in CSV, write it
                csv_data[vendor_tuple] += 1
                with open(csv_file_path, 'a', newline='', encoding='utf-8') as csv_file_append:
                    csv_writer = csv.writer(csv_file_append)
                    csv_writer.writerow(row)
                print(f'Added {vendor_name} to CSV.')
    # Step 5: Ensure uniqueness in CSV
    for vendor_tuple, count in csv_data.items():
        if count > 1:
            print(f'Duplicate entry in CSV for vendor: {vendor_tuple}')

def date_format_sheets(date_obj):
    try:
        formatted_date = date_obj.strftime("%m-%d-%Y")
        return formatted_date
    except AttributeError:
        print("this is not a datetime object, skipping")
        return ''

def update_product_in_sheets(new_quantity: int, ref_id: str, lot_number: str, expiry_date) -> None:
    SPREADSHEET_ID = "1HwJeDoho1MHS3NJxLdJZgse7YP3A-6C1KIw8YzSX9Eo"  # spreadsheet_id of main Current Inventory
    RANGE_NAME = "Current Inventory"
    SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
    secret_file = os.path.join(os.getcwd(), 'client_secret_omni_z.json')
    creds = service_account.Credentials.from_service_account_file(secret_file, scopes=SCOPES)
    service = discovery.build("sheets", "v4", credentials=creds)
    result = (
        service.spreadsheets()
        .values()
        .get(spreadsheetId=SPREADSHEET_ID, range=RANGE_NAME)
        .execute()
    )
    values = result.get("values", [])
    df = pd.DataFrame(data=values[1:], columns=values[0])
    df.rename(columns={"Vendor": "vendor",
        "Quantity": "quantity",
        "Product Name": "name",
        "Product Size": "size",
        "expiry_date": "expiry_date",
        "reference_id": "ref_id",
        "Lot_Number": "lot_number",
        "Barcode": "barcode",
        "Last Modified On": "last_modified"}, inplace=True)
    df["expiry_date"] = pd.to_datetime(df["expiry_date"], format="mixed")
    # df["last_modified"] = pd.to_datetime(df["last_modified"], format="mixed")
    expiry_date_object = pd.to_datetime(expiry_date)
    filtered_df = df[(df['ref_id'] == ref_id) & (df['lot_number'] == lot_number) & (df['expiry_date'] == date_format_sheets(expiry_date_object))]
    # Iterate through the filtered DataFrame and update the cells in the Google Sheet
    for row in filtered_df.itertuples(index=True):
        row_index = row[0] + 2  # adjusting for 0-based index and header row
        print(row_index)
        # column_name = 'Quantity' # column to be updated
        column_name = 'B' # change this if location of quantity changes in column (A1 notation)
        new_value = new_quantity
        print(row)
        print(new_value, 'new val at line 285 views')
        # translate row and column information to Google Sheets range, then update
        # cell_range = f"{column_name}{row_index}"
        cell_range = f"Current Inventory!{column_name}{row_index}"
        # Define the request body to update the cell with new_value
        print('cell range is', cell_range)
        update_body = {
        "values": [[new_value]]
        }
        # Perform the update request
        try:
            update_result = (
            service.spreadsheets()
            .values()
            .update(
            spreadsheetId=SPREADSHEET_ID,
            range=cell_range,
            body=update_body,
            valueInputOption="RAW"  # Use "RAW" for plain text values
            )
            .execute()
            )
            print("Value successfully updated for item via Sheets API.")
        except Exception as e:
            print("Sheet or column range needs to be verified on the main sheet.", str(e))
            traceback.print_exc()


def get_data_from_api(params: list) -> pd.DataFrame:
    with thread_lock:
        SPREADSHEET_ID_MAIN = "1HwJeDoho1MHS3NJxLdJZgse7YP3A-6C1KIw8YzSX9Eo"
        RANGE_NAME_ITEMS_ADDED = "New Items for Inventory FORM"
        RANGE_NAME_ITEMS_USED = "Items Used in Procedure FORM"
        RANGE_NAME_MAIN_INVENTORY = "Current Inventory"
        range_name = params[0]
        SPREADSHEET_ID = SPREADSHEET_ID_MAIN
        RANGE_NAME = range_name
        SCOPES = ["https://www.googleapis.com/auth/spreadsheets"]
        secret_file = os.path.join(os.getcwd(), 'client_secret_omni_z.json')
        creds = service_account.Credentials.from_service_account_file(secret_file, scopes=SCOPES)
        try:
            service = discovery.build("sheets", "v4", credentials=creds)
            result = (
                service.spreadsheets()
                .values()
                .get(spreadsheetId=SPREADSHEET_ID, range=RANGE_NAME)
                .execute()
            )
            values = result.get("values", [])
            df = pd.DataFrame(data=values[1:], columns=values[0])
            if params[1] == True:
                CSV_FILE = f"current-inventory-asof-{datetime.now().date().strftime('%m-%d-%Y--%H_%M_%S')}.csv"
                df.to_csv(CSV_FILE)
                return CSV_FILE
            return df
        except HttpError as error:
            print(f"An error occurred: {error}")
            traceback.print_exc()
            return error

def items_added_30days(df: pd.DataFrame)-> pd.DataFrame:
    try:
        df.rename(columns={
            "Quantity Received": "quantity_received",
            "Category": "category",
            "Vendor": "vendor",
            "Product Name": "name",
            "Product Size": "size",
            "expiry_date": "expiry_date",
            "reference_id": "ref_id",
            "Lot_Number": "lot_number",
            "Barcode": "barcode",
            "Timestamp":"date_added"
            }, inplace=True)
        df["expiry_date"] = pd.to_datetime(df["expiry_date"], format="mixed")
        df["date_added"] = pd.to_datetime(df["date_added"], format="mixed")
        start_date = pd.to_datetime(date.today())
        end_date = pd.to_datetime(start_date - timedelta(days=1 * 30))
        date_condition = (df["date_added"] <= start_date) & (df["date_added"] >= end_date)
        filtered_df = df[date_condition]
        # filtered_df.sort_values(by="expiry_date", inplace=True)
        filtered_df.sort_values(by="date_added", inplace=True)
        return filtered_df
    except OSError:
        traceback.print_exc()

def items_used_30days(df: pd.DataFrame)-> pd.DataFrame:
    try:
        df.rename(columns={"Quantity Used": "quantity_used",
            "Vendor": "vendor",
            "Product Name": "name",
            "Product Size": "size",
            # "expiry_date": "expiry_date", # removed expiry_date here, not present as column in sheet
            "reference_id": "ref_id",
            "Lot_Number": "lot_number",
            "Barcode": "barcode",
            "MRN-Procedure Name": "mrn_procedure",
            "Procedure Date": "date_used",
            "Timestamp":"date_inventory_updated"
            }, inplace=True)
        # df["expiry_date"] = pd.to_datetime(df["expiry_date"], format="mixed")
        df["date_used"] = pd.to_datetime(df["date_used"], format="mixed")
        start_date = pd.to_datetime(date.today())
        end_date = pd.to_datetime(start_date - timedelta(days=1 * 30))
        date_condition = (df["date_used"] <= start_date) & (df["date_used"] >= end_date)
        filtered_df = df[date_condition]
        filtered_df.sort_values(by="date_used", inplace=True)
        return filtered_df
    except OSError:
        traceback.print_exc()


# @transaction.atomic
def update_db_from_inventory_csv(file):
    print("Starting update to Database:")
    print("Syncing vendors with CSV file..")
    sync_vendors_with_csv()
    print("Updating from current inventory...")
    with thread_lock:
        with open(file, "r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for index, row in enumerate(reader, start=1):
                expiry = row["expiry_date"].strip()
                ref = row["reference_id"].strip()
                lot_number = row["Lot_Number"].strip()
                vendor = row["Vendor"].strip()
                product = row["Product Name"].strip()
                ref_id_lot_number_expiry_date = f"{ref}***{lot_number}***{expiry}"
                size = row["Product Size"].strip()
                quantity = row["Quantity"].strip()
                barcode = row["Barcode"].strip()
                # row_number = index
                if 'ev3' in vendor or 'Covidien' in vendor:
                    vendor = 'Medtronic' # this is because vendor has multiple names/entities owned
                defaults={
                        "name": product,
                        "reference_id": ref,
                        "expiry_date": db_date_format(expiry),
                        "lot_number": lot_number,
                        "ref_id_lot_number_expiry_date": ref_id_lot_number_expiry_date,
                        "size": size,
                        "barcode": barcode,
                        "employee": User.objects.get(id=1),
                        "vendor": Vendor.objects.get(name__icontains=vendor),
                        "quantity_on_hand": quantity,
                    }
                try:
                    obj = Product.objects.get(reference_id=ref, lot_number=lot_number, expiry_date=db_date_format(expiry))
                    for key, value in defaults.items():
                        setattr(obj, key, value)
                    obj.save()
                    print(f"{product} updated in db successfully.")
                except Product.DoesNotExist:
                    new_values = defaults
                    obj = Product(**new_values)
                    obj.save()
                    print(f"{product} created new in db successfully.")
        print("Database update complete, now based on current inventory.")




from django.db import models
# from django.template.defaultfilters import date
from django.core.exceptions import ValidationError
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.utils.translation import gettext_lazy as _
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
from django.contrib.auth.models import User
import json
import pandas as pd
import traceback
from django.db import transaction
import csv


class Vendor(models.Model):
    id = models.AutoField(primary_key=True, unique=True)
    name = models.CharField(max_length=200, unique=True)
    abbrev = models.CharField(max_length=50, unique=True)
    # url = models.URLField(max_length=200)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)

    def __str__(self) -> str:
        return self.name


class AuditLog(models.Model):
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey("content_type", "object_id")
    field_name = models.CharField(max_length=255)
    old_value = models.CharField(max_length=255)
    new_value = models.CharField(max_length=255)
    modified_date = models.DateTimeField()
    omni_employee = models.PositiveIntegerField(
        "Employee last edited", blank=False, default=1
    )
    def get_quantity_field(self):
        return (
            f"Quantity on hand"
            if "{quantity_on_hand}" in self.field_name
            else "Not yet defined field name"
        )
    # p = Product.objects.filter(pk=1)

    # def __str__(self) -> str:
    #     return f"Value changed: {self.get_field_name()}, Old value: {self.old_value}, New value: {self.new_value}, Date changed: {self.modified_date}"

class Product(models.Model):
    id = models.BigAutoField(
        auto_created=True,
        primary_key=True,
        unique=True,
        serialize=False,
        verbose_name="ID",
    )
    name = models.CharField(max_length=300)
    reference_id = models.CharField(max_length=100)
    expiry_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    ref_id_lot_number_expiry_date = models.CharField(max_length=250, unique=True)
    # barcode_ref_id_expiry_date = models.CharField(max_length=250, unique=True, default="N/A")
    is_purchased = models.BooleanField(default=True)
    size = models.CharField(max_length=60, default="N/A", blank=True)
    barcode = models.CharField(max_length=300, default="N/A", blank=True, null=True)
    lot_number = models.CharField(max_length=300, default="N/A", blank=True, null=True)
    quantity_on_hand = models.PositiveIntegerField(default=1)
    quantity_on_order = models.PositiveIntegerField(default=0)
    last_modified = models.DateTimeField(auto_now=True)
    employee = models.ForeignKey(User, blank=True, null=True, on_delete=models.SET_NULL)
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE)

    def save(self, *args, **kwargs):
        # self.ref_id_lot_number_expiry_date = (
        #     self.generate_ref_id_lot_number_expiry_date_field()
        # )
        # self.barcode_ref_id_expiry_date = self.generate_barcode_ref_id_expiry_field()
        if self.pk:
            # Retrieve the existing object from the database
            old_instance = Product.objects.get(pk=self.pk)
            # Compare the fields and record changes
            for field in self._meta.fields:
                field_name = field.name
                old_value = getattr(old_instance, field_name)
                new_value = getattr(self, field_name)
                if old_value != new_value:
                    # Create an audit log entry for each changed field
                    # user = User.objects.get(id=)
                    AuditLog.objects.create(
                        content_object=self,
                        field_name=field_name,
                        old_value=str(old_value),
                        new_value=str(new_value),
                        modified_date=datetime.now(),
                        omni_employee=self.employee.id,
                    )
        super().save(*args, **kwargs)

    # def generate_ref_id_lot_number_expiry_date_field(self):
    #     return f"{self.reference_id}***{self.lot_number}***{self.expiry_date.date()}"

    # def generate_barcode_ref_id_expiry_field(self):
    #     return f"{self.barcode}***{self.reference_id}***{self.expiry_date.date()}"

    class Meta:
        unique_together = ("reference_id", "expiry_date", "lot_number")
        # ordering = ["name"]
        ordering = ["expiry_date"]
        indexes = [models.Index(fields=["ref_id_lot_number_expiry_date", "name"])]

    def __str__(self) -> str:
        return self.name

    @property
    def days_until_expiry(self):
        today = date.today()
        # expiry_converted = [int(n) for n in self.expiry_date.split("-")]

        time_remaining = relativedelta(self.expiry_date.date(), today)
        # days_remaining = relativedelta(datetime(*expiry_converted).date(), today)
        # days_remaining = datetime(*expiry_converted).date() - today
        # days_remaining_str = str(days_remaining).split(",", 1)[0]
        return time_remaining

 # need to refine Procedure model, to be able to handle Product objects
 # as a ManyToMany or OneToMany field for products_used
class Procedure(models.Model):
    # id = models.BigAutoField(
    #     auto_created=True,
    #     primary_key=True,
    #     unique=True,
    #     serialize=False,
    #     verbose_name="Procedure ID",)
    procedure = models.CharField(max_length=300, blank=False, null=False)
    patient = models.CharField(max_length=300, blank=False, null=False)
    date_performed = models.DateTimeField(auto_now=True)
    # products_used = models.ManyToManyField(Product)
    products_used = models.CharField(max_length=300, blank=False, null=False)
    employee = models.ForeignKey(User, blank=True, null=True, on_delete=models.SET_NULL)

    # CHOICES = [("1", "Add to Inventory"), ("2", "Delete from Inventory")]
    # choice_field = models.CharField(max_length=1, choices=CHOICES)
    class Meta:
        unique_together = ("patient", "date_performed")
        ordering = ["date_performed"]
        indexes = [models.Index(fields=["patient", "procedure"])]

    def __str__(self) -> str:
        return self.procedure


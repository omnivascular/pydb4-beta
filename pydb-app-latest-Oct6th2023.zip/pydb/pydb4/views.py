from django.shortcuts import render, redirect
from .models import Product, Vendor, AuditLog, Procedure
from django.contrib.auth.models import User
from django.db.models import Q
# from datetime import datetime
import datetime, pytz
# import json
from .forms import ProductForm, ProcedureForm, VendorForm
# from .forms import UneditableProductForm
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse #, HttpResponseNotAllowed
from django.urls import reverse
from django.contrib import messages
from calendar import HTMLCalendar
import calendar
# from django.core import serializers
# from django.views.decorators.cache import cache_control
import traceback
# import qrcode as qr
import re
from .db_api_sync_sec import get_data_from_api, update_db_from_inventory_csv, db_date_format, db_date_format_alt, update_product_in_sheets, construct_search_query, construct_search_query_alternate, items_added_30days, items_used_30days
import threading
import pandas as pd


thread_lock = threading.Lock()


def all_products(request):
    product_list = Product.objects.all()
    return render(request, "pydb4/product_list.html", {"product_list": product_list})


def all_vendors(request):
    vendor_list = Vendor.objects.all()
    return render(
        request,
        "pydb4/vendor_list.html",
        {"vendor_list": vendor_list},
    )


def database_update_current_inventory(request):
    with thread_lock:
        try:
            data = get_data_from_api(["Current Inventory", True]) # this will gather CSV file
            update_db_from_inventory_csv(data) # this will pass CSV file to db update function
            product_list = Product.objects.all()
            messages.success(request, "Current inventory updated successfully from CSV!")
            return render(
                request,
                "pydb4/product_list.html",
                {"product_list": product_list},
            )
        except Exception as e:
            traceback.print_exc()
            messages.success(request, "Error with updating current inventory, please see stack trace and IT admin.")
            product_list = Product.objects.all()
            return render(
                request,
                "pydb4/product_list.html",
                {"product_list": product_list},
            )


def all_procedures(request):
    procedure_list = Procedure.objects.all()
    return render(
        request,
        "pydb4/procedure_list.html",
        {"procedure_list": procedure_list},
    )


def all_vendor_products(request, vendor_id):
    print(request.META.get('HTTP_X_REQUESTED_WITH'))
    if request.META.get('HTTP_X_REQUESTED_WITH') == 'XMLHttpRequest':
        products = Product.objects.filter(vendor_id=vendor_id)
        vendor = Vendor.objects.get(id=vendor_id)
        product_data = [{"name": p.name} for p in products]
        vendor_data = {
            'id': vendor.id,
            'name': vendor.name,
            # Can add any other desired fields
        }
        response_data = {
            'products': product_data,
            'vendor': vendor_data,
        }
        # response_json = json.dumps(response_data)
        return JsonResponse(response_data, safe=False)
    else:
        products = Product.objects.filter(vendor_id=vendor_id)
        vendor = Vendor.objects.get(id=vendor_id)
        return render(
            request,
            "pydb4/vendor_products.html",
            {"products": products, "vendor": vendor},
        )


def product_detail(request, item_id):
    product = Product.objects.get(id=item_id)
    try:
        auditor = AuditLog.objects.get(id=product.employee.id)
        modifier = User.objects.get(id=auditor.omni_employee)
    except AttributeError:
        print(f'{product.name} needs admin as default auditor.')
        auditor = AuditLog.objects.get(id=1)
        modifier = User.objects.get(id=auditor.omni_employee)
    records = AuditLog.objects.filter(Q(object_id=item_id) & Q(field_name="quantity_on_hand")).order_by('-modified_date')
    # for r in records:
    #     print(r.content_object)
    #     print(r.object_id)
    #     print(r.field_name)
    return render(request, "pydb4/product_detail.html", {"product": product, "records": records, "modifier": modifier})


def product_search(request):
    multiple = ''
    if request.method == "POST":
        searched = request.POST["searched"]
        if request.POST.get("search_option") == 'barcode':
            multiple = 'barcode'
            products = [s.strip().lower() for s in searched.split("-")]
            queries = [Q(name__icontains=term) | Q(size__icontains=term) | Q(barcode__icontains=term) | Q(reference_id__icontains=term) | Q(lot_number__icontains=term) | Q(expiry_date__exact=db_date_format_alt(term)) for term in products]
            search_query = construct_search_query_alternate(queries)
            results = Product.objects.filter(search_query).order_by('expiry_date')
            return render(request, "pydb4/product_search.html", {"searched": products, "products": results, "multiple": multiple})
        elif request.POST.get("search_option") == 'multiple':
            multiple = 'multiple'
            products = [s.strip().lower() for s in searched.split(" ")]
            queries = [Q(name__icontains=term) | Q(size__icontains=term) | Q(reference_id__icontains=term) | Q(barcode__icontains=term) | Q(lot_number__icontains=term) | Q(expiry_date__exact=db_date_format_alt(term)) for term in products]
            search_query = construct_search_query(queries)
            results = Product.objects.filter(search_query).order_by('expiry_date')
            return render(request, "pydb4/product_search.html", {"searched": products, "products": results, "multiple": multiple})
        elif request.POST.get("search_option") == 'single':
            multiple = 'single'
            products = [s.strip().lower() for s in searched.split(" ")]
            queries = [Q(name__icontains=term) | Q(size__icontains=term) | Q(barcode__icontains=term) | Q(reference_id__icontains=term) | Q(lot_number__icontains=term) | Q(expiry_date__exact=db_date_format_alt(term)) for term in products]
            search_query = construct_search_query_alternate(queries)
            results = Product.objects.filter(search_query).order_by('expiry_date')
            return render(request, "pydb4/product_search.html", {"searched": products, "products": results, "multiple": multiple})
        else:
            products = Product.objects.filter(Q(name__icontains=searched)|Q(size__icontains=searched)|Q(reference_id__icontains=searched) | Q(barcode__icontains=searched) | Q(lot_number__icontains=searched) | Q(expiry_date__exact=db_date_format_alt(searched))).order_by('expiry_date')
            messages.success(request, "Nice search, it worked!", extra_tags='search')
            return render(
                request,
                "pydb4/product_search.html",
                {
                    "searched": searched,
                    "products": products,
                    "multiple": multiple,
                },
            )
    else:
        return render(request, "pydb4/product_list.html", {})


def update_product(request, product_id):
    product = Product.objects.get(pk=product_id)
    updated = False
    readonly_fields = ['name', 'reference_id', 'size', 'expiry_date', 'vendor']
    # readonly_fields = ['name', 'reference_id', 'expiry_date', 'vendor']
    if request.method == "POST":
        print(request)
        form = ProductForm(request.POST, instance=product, readonly_fields=readonly_fields)
        if form.is_valid():
            result = form.save(commit=False)
            try:
                result.employee = User.objects.get(pk=request.user.id) #logged in user
            except Exception:
                traceback.print_exc()
            print(f'For updating {product.name}, User ID: {request.user.id}')
            update_product_in_sheets(result.quantity_on_hand, result.reference_id, result.lot_number, result.expiry_date)
            result.save()
            updated = True
            redirect_url = reverse('product_detail', args=[product_id])
            if updated:
                redirect_url += '?redirect_flag=true'
            print(result.employee.username)
            redirect_url += f'?user={result.employee.username}'
            return HttpResponseRedirect(redirect_url)
        else:
            messages.error(request, "Form unable to be saved, please contact IT admin.")
    else:
        form = ProductForm(instance=product, readonly_fields=readonly_fields)
    return render(request, 'pydb4/update_product.html', {"product": product, "form": form, "readonly_fields": readonly_fields})


def report_items_added_30days(request):
    data_df = get_data_from_api(["New Items for Inventory FORM", False]) # this gathers df of items new
    data_df_processed = items_added_30days(data_df)
    items_dict = data_df_processed.to_dict(orient="records")
    # above is a list of dict objects that represent data from sheets file reflecting items added last 30 days,
    # can also check this versus database, match items, and then pass those products (as QuerySet dict) to context object
    # so that it could be easier to define properly in the html template
    product_list = items_dict
    return render(request, "pydb4/products_added_30days_report.html", {"product_list": product_list})

# mirror of above, if comments needed
def report_items_used_30days(request):
    data_df = get_data_from_api(["Items Used in Procedure FORM", False]) # this gathers df of items used
    print("this is DF of items used data, preprocessing")
    data_df_processed = items_used_30days(data_df)
    print(data_df_processed)
    # list of attributes to add as columns, these are absent from the items used sheet
    attributes_to_add = ['name', 'reference_id', 'id', 'expiry_date', 'quantity_on_hand', 'vendor', 'size', 'lot_number']
    barcode_list = data_df_processed["barcode"]
    # Create a dictionary to collect attribute data for each barcode
    data_dict = {}
    for barcode in barcode_list:
        barcode = str(barcode).strip()
        print(barcode)
        # Get all objects with the matching barcode
        objs = Product.objects.filter(barcode__icontains=barcode)
        # Create a list to store attribute data for each object
        objs_data = []
        for obj in objs:
            # Create a dictionary to store attribute data for this object
            obj_data = {}
            # Collect attribute values for this object
            for attribute in attributes_to_add:
                obj_data[attribute] = getattr(obj, attribute)
            # Add the collected data for this object to the list
            objs_data.append(obj_data)
        # Add the list of attribute data for this barcode to the main data dictionary
        data_dict[barcode] = objs_data
    # Now, data_dict holds lists of attribute data for each barcode
    # You can decide how to proceed with this data, whether to flatten it or keep it nested
    # Example: Flattening the data for each barcode into a single dictionary
    flattened_data_dict = {}
    for barcode, objs_data in data_dict.items():
        # Merge the dictionaries for each object into a single dictionary
        flattened_data_dict[barcode] = {k: v for obj_data in objs_data for k, v in obj_data.items()}
    # Convert the flattened data dictionary into a DataFrame
    additional_data_df = pd.DataFrame.from_dict(flattened_data_dict, orient='index')
    print('this is additional data df:')
    print(additional_data_df)
    data_df_processed = data_df_processed.merge(additional_data_df, left_on='barcode', right_index=True)
    items_dict = data_df_processed.to_dict(orient="records")
    product_list = items_dict
    return render(request, "pydb4/products_used_30days_report.html", {"product_list": product_list})

def expiry_check_products_by_month(request, month_number):
    products = Product.objects.all()
    results = []
    for x in products:
        datecheck = x.days_until_expiry
        if month_number == 1:
            if datecheck.years == 0 and datecheck.months <= 1:
                print(x.name, x.size, x.expiry_date.date())
                results.append(x)
        if month_number == 3:
            if datecheck.years == 0 and datecheck.months <= 3 and datecheck.months > 1:
                print(x.name, x.size, x.expiry_date.date())
                results.append(x)
        if month_number == 6:
            if datecheck.years == 0 and datecheck.months <= 6 and datecheck.months > 3:
                print(x.name, x.size, x.expiry_date.date())
                results.append(x)
    return render(request, 'pydb4/expiry_check.html', {"results": results, "month_number": month_number})

# def verify_products(request):
#     submitted = False
#     if request.method == "POST":
#         print('got to here, line 201 in views.py')
#         pattern = r"\r\n|\n|,"  # Regular expression pattern to match "\r\n" or "\n"
#         barcodes_used = re.split(pattern, request.POST.get('products_used', ''))
#         queries = [Q(barcode__icontains=term) for term in barcodes_used if term != '']
#         search_query = construct_search_query(queries)
#         results = Product.objects.filter(search_query).order_by('expiry_date')

#     print('got to here, line 209 in views.py')
#     return HttpResponseNotAllowed(['POST'])

def procedure(request):
    submitted = False
    if request.method == "POST":
        print("POST here")
        form = ProcedureForm(request.POST)
        pattern = r"\r\n|\n|,"  # Regular expression pattern to match "\r\n" or "\n"
        barcodes_used = re.split(pattern, request.POST.get('products_used'))
        # products = list(set([Product.objects.filter(barcode__exact=b) for b in barcodes_used]))
        isolated_barcodes = set()
        uniques = [x for x in barcodes_used if x not in isolated_barcodes and not isolated_barcodes.add(x)]
        duplicates = [x for x in barcodes_used]
        barcodes_exist = all(list(set([Product.objects.filter(barcode__exact=b).exists() for b in barcodes_used if b != ''])))
        # if barcodes_exist:
        # need to add logic for item barcodes that don't exist yet (could then show popup of add_product page)
        queries = [Q(barcode__icontains=term) for term in barcodes_used if term != '']
        search_query = construct_search_query(queries)
        results = Product.objects.filter(search_query).order_by('expiry_date')
        print('length of results queryset:')
        print(len(results))
        print('.items: ', request.POST.items)
        print('original products used field: ', barcodes_used)
        # print('processed products used field', products_used)
        print('patient: ', request.POST.get('patient'))
        print('procedure: ', request.POST.get('procedure'))
        if form.is_valid():
            print(type(form))
            print('it is valid')
            procedure = form.save(commit=False)
            try:
                print('For adding procedure, User ID: ', request.user.id)
                procedure.employee = User.objects.get(pk=request.user.id) #logged in user
                procedure.products_used = barcodes_used
                if results:
                    print('showing len, type, and results object itself:')
                    print(len(results), type(results), results)
                    for r in results:
                        print(f"Removing one of this item from inventory: {r.name}-{r.expiry_date}")
                        print(f"Old quant: {r.quantity_on_hand}")
                        r.quantity_on_hand -= 1
                        print(f"New quant: {r.quantity_on_hand}")
                        r.save()
                        print(f'saved {r}')
                # product.employee = request.user.id
                procedure.save()
            except:
                traceback.print_exc()
            submitted = True
            return render(request, 'pydb4/procedure_detail.html', {'procedure': procedure, 'submitted': submitted, 'barcodes': barcodes_used, 'products': results})
        else:
            print(procedure.is_valid())
            print(procedure.errors)
            print('sorry form not correct, try again.')
            return render(request, 'pydb4/procedure_event.html', {'procedure': procedure})
    else:
        form = ProcedureForm()
        print('GET here')
        return render(request, 'pydb4/procedure_event.html', {'form': form, 'submitted': submitted})


def add_product(request):
    submitted = False
    if request.method == "POST":
        form = ProductForm(request.POST)
        if form.is_valid():
            # venue = form.save(commit=False)
            # venue.owner = request.user.id # logged in user
            # venue.save()
            product = form.save(commit=False)
            try:
                print('For adding product, User ID: ', request.user.id)
                product.employee = User.objects.get(pk=request.user.id) #logged in user
                # product.employee = request.user.id
                product.save()
            except:
                traceback.print_exc()
            submitted = True
            messages.success(request, "Product added successfully.")
            # return  render('/add_product?submitted=True')
            print(type(product))
            return render(request, "pydb4/product_detail.html", {"product": product, 'submitted': submitted})
    else:
        form = ProductForm()
        if 'submitted' in request.GET:
            submitted = True
        return render(request, 'pydb4/add_product.html', {'form':form, 'submitted':submitted})


def add_vendor(request):
    submitted = False
    if request.method == "POST":
        form = VendorForm(request.POST)
        vendors = Vendor.objects.filter(id=request.POST.get("id"), name=request.POST.get("name"), abbrev=request.POST.get("abbrev"))
        if not vendors.exists():
            if form.is_valid():
                try:
                    vendor = form.save(commit=False)
                    print('Adding new vendor, Vendor ID: ', vendor.id)
                    vendor.employee = User.objects.get(pk=request.user.id)  # logged in user
                    vendor.save()
                    messages.success(request, "Vendor added successfully.")
                    submitted = True
                    products = Product.objects.filter(vendor_id=vendor.id)
                    return render(request, "pydb4/vendor_products.html", {"vendor": vendor, 'submitted': submitted, 'products': products})
                except Exception as e:
                    traceback.print_exc()
                    print('An error occurred:', str(e))
                    return HttpResponse("An error occurred while adding the vendor. Please try again later.")
            else:
                # Handle form validation errors here
                print('Form errors here:', form.errors)
                messages.success(request, f"Form validation failed. Please check the data you entered: \n All Vendor information must be unique (ID, Name, Abbreviation).")
                vendor_list = Vendor.objects.all()
                return render(
                    request,
                    "pydb4/vendor_list.html",
                    {"vendor_list": vendor_list},
                )
        else:
            vendor = vendors.first()
            messages.success(request, "Vendor already exists in records.")
            products = Product.objects.filter(vendor_id=vendor.id)
            return HttpResponseRedirect(reverse('all-vendor-products', args=[vendor.id]))  # Redirect to vendor detail page
    else:
        form = VendorForm()
        if 'submitted' in request.GET:
            submitted = True
        return render(request, 'pydb4/add_vendor.html', {'form': form, 'submitted': submitted})

def home(request, year=datetime.datetime.now().year, month=datetime.datetime.now().strftime('%B')):
    name = "Guest"
    month = month.capitalize()
    # Convert month from name to number
    month_number = list(calendar.month_name).index(month)
    month_number = int(month_number)
    # create a calendar
    cal = HTMLCalendar().formatmonth(
        year,
        month_number)
    # Get current year
    # now = datetime.now()
    now = datetime.datetime.now(tz=pytz.timezone("US/Eastern"))
    current_year = now.year
    current_day = now.day
    # Query the Events Model For Dates
    # event_list = Event.objects.filter(
    #     event_date__year = year,
    #     event_date__month = month_number
    #     )
    # Get current time
    time = now.strftime('%I:%M %p')
    return render(request,
        'pydb4/home.html', {
        "name": name,
        "year": year,
        "month": month,
        "month_number": month_number,
        "cal": cal,
        "current_day": current_day,
        "current_year": current_year,
        "time":time,
        # "event_list": event_list,
        })

from dateutil.relativedelta import relativedelta
from datetime import date, datetime, timedelta
import pandas as pd

def api_test():
    SPREADSHEET_ID = (
        "1RxgAXxiuERj1QF3xrMXSP5Ed-9PYglHBnoaWb7q62AY"  # Copy_Current_Inventory sheet
    )
    RANGE_NAME = "Sheet1"
    CSV_FILE = f"current-inventory-asof-{datetime.now().date().strftime('%m-%d-%Y--%H_%M_%S')}.csv"
    SCOPES = ["https://www.googleapis.com/auth/spreadsheets.readonly"]
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                r"C:\Users\omniv\OneDrive\Documents\py5\pydb4\pydb\credentials.json",
                SCOPES,
            )
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    service = build("sheets", "v4", credentials=creds)
    result = (
        service.spreadsheets()
        .values()
        .get(spreadsheetId=SPREADSHEET_ID, range=RANGE_NAME)
        .execute()
    )
    values = result.get("values", [])
    df = pd.DataFrame(data=values[1:], columns=values[0])
    df.rename(
        columns={
            "Vendor": "vendor",
            "Quantity": "quantity",
            "Product Name": "name",
            "Product Size": "size",
            "expiry_date": "expiry_date",
            "reference_id": "ref_id",
            "Lot_Number": "lot_number",
            "Barcode": "barcode",
            "Last Modified On": "last_modified",
        },
        inplace=True,
    )
    df["expiry_date"] = pd.to_datetime(df["expiry_date"], format="mixed")
    # df["last_modified"] = pd.to_datetime(df["last_modified"], format="mixed")
    # df["date_string_column"] = df["expiry_date"].dt.strftime("%m-%d-%Y")
    # ---- below reformats datetime object of column into a string of date formatted as Sept. 19, 2023 ----
    df["date_string_column"] = df["expiry_date"].dt.strftime("%b. %d, %Y")
    df1 = df[["name", "barcode", "date_string_column", "lot_number"]]
    df1["qr_code_string"] = (
        df1["name"]
        + "-"
        + df1["barcode"]
        + "-"
        + df1["date_string_column"]
        + "-"
        + df1["lot_number"]
    )

    return df1

def api_test():
    SPREADSHEET_ID = (
        "1RxgAXxiuERj1QF3xrMXSP5Ed-9PYglHBnoaWb7q62AY"  # Copy_Current_Inventory sheet
    )
    RANGE_NAME = "Sheet1"
    CSV_FILE = f"current-inventory-asof-{datetime.now().date().strftime('%m-%d-%Y--%H_%M_%S')}.csv"
    SCOPES = ["https://www.googleapis.com/auth/spreadsheets.readonly"]
    creds = None
    if os.path.exists("token.json"):
        creds = Credentials.from_authorized_user_file("token.json", SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                r"C:\Users\omniv\OneDrive\Documents\py5\pydb4\pydb\credentials.json",
                SCOPES,
            )
            creds = flow.run_local_server(port=0)
        with open("token.json", "w") as token:
            token.write(creds.to_json())
    service = build("sheets", "v4", credentials=creds)
    result = (
        service.spreadsheets()
        .values()
        .get(spreadsheetId=SPREADSHEET_ID, range=RANGE_NAME)
        .execute()
    )
    values = result.get("values", [])
    df = pd.DataFrame(data=values[1:], columns=values[0])
    df.rename(
        columns={
            "Vendor": "vendor",
            "Quantity": "quantity",
            "Product Name": "name",
            "Product Size": "size",
            "expiry_date": "expiry_date",
            "reference_id": "ref_id",
            "Lot_Number": "lot_number",
            "Barcode": "barcode",
            "Last Modified On": "last_modified",
        },
        inplace=True,
    )
    df["expiry_date"] = pd.to_datetime(df["expiry_date"], format="mixed")
    # df["last_modified"] = pd.to_datetime(df["last_modified"], format="mixed")
    # df["date_string_column"] = df["expiry_date"].dt.strftime("%m-%d-%Y")
    df["date_string_column"] = df["expiry_date"].dt.strftime("%b. %d, %Y")
    df1 = df[["name", "quantity", "barcode", "date_string_column", "lot_number"]]
    df1["qr_code_string"] = (
        df1["name"]
        + "-"
        + df1["barcode"]
        + "-"
        + df1["date_string_column"]
        + "-"
        + df1["lot_number"]
    )
    # below will duplicate rows based on 'quantity'(or any other column), confirmed works
    df1 = df1.loc[df.index.repeat(df["quantity"])]

    # Reset the index
    df1.reset_index(drop=True, inplace=True)

    # --- below does not work with Series upon a df, shapes are different
    # # Duplicate rows based on the 'quantity' column
    # df1 = pd.concat([df1] * df1["quantity"], ignore_index=True)
    # # Reset the index
    # df1.reset_index(drop=True, inplace=True)
    return df1


# val = api_test()
# val = val[["quantity", "name", "qr_code_string"]]
# print(val)
# val.to_csv("for_zee_2.csv")


# val = api_test()
# val = val[["name", "qr_code_string"]]

# convert from string into datetime object, in the given format of date (will be YYYY-mm-dd ultimately)
def convert_str_mm_dd_yyyy_to_datetime_yyyy_mm_dd(date_str):
    date_object = datetime.strptime(date_str, "%m-%d-%Y")
    formatted_date = date_object.strftime("%Y-%m-%d")
    date = datetime.strptime(formatted_date, "%Y-%m-%d")
    return date

# val has to be a datetime object, if not, then converted first using above helper function
def time_remaining_till_expiry(val):
	today = date.today()
	time_remaining = relativedelta(val.date(), today)
	return time_remaining

# df has will be pandas dataframe object, read from csv, set at 9months from now currently
# also sorts by expiry, returns new df and exported into its own csv
def find_products_by_expiry(file):
    df = pd.read_csv(file)
    df['expiry_date'] = pd.to_datetime(df['expiry_date'], format="%m-%d-%Y")
	start_date = pd.to_datetime(date.today())
	end_date = pd.to_datetime(start_date + timedelta(days=9 * 30))
	date_condition = (df["expiry_date"] >= start_date) & (df["expiry_date"] <= end_date)
	filtered_df = df[date_condition]
	filtered_df.sort_values(by="expiry_date", inplace=True)
	filtered_df.to_csv(f"products_expiry_9months_{datetime.now().date()}.csv", index=False)
	return filtered_df

# file should be csv, full path string, as in r""
def sort_products_by_name_then_expiry(file):
	df = pd.read_csv(file)
	df['expiry_date'] = pd.to_datetime(df['expiry_date'], format="%m-%d-%Y")
	product_names = df['product'].unique()
	separated_rows = []
	for product_name in product_names:
		product_df = df[df['product'] == product_name].copy()
		product_df.sort_values(by='expiry_date', inplace=True)
		# can add empty rows to increase spacing
		# separated_rows.extend({}, {}, {})
		# also adding product name as header row, can be removed if needed
		separated_rows.append({'Product': product_name})
		product_df.sort_values(by='expiry_date', inplace=True)
		separated_rows.extend(product_df.to_dict('records'))
	sorted_df = pd.DataFrame(separated_rows)
	sorted_df.to_csv(f"collated_by_products_expiry_{datetime.now().date()}.csv", index=False)



"""
additional date formatting if needed:

def convert_str_to_django_db_format_yyyy_mm_dd(date_str):
    date = datetime.strptime(date_str, "%m-%d-%Y")
    return date.strftime("%Y-%m-%d")


def convert_str_to_datetime_mm_dd_yyyy(date_str):
    date = datetime.strptime(date_str, "%Y-%m-%d")
    return date.strftime("%m-%d-%Y")


def convert_str_to_db_search_format_yyyy_mm_dd(date_str):
    date = datetime.strptime(date_str, "%Y-%m-%d")
    return date


def convert_str_mm_dd_yyyy_to_datetime_yyyy_mm_dd(date_str):
    date_object = datetime.strptime(date_str, "%m-%d-%Y")
    formatted_date = date_object.strftime("%Y-%m-%d")
    date = datetime.strptime(formatted_date, "%Y-%m-%d")
    return date


"""